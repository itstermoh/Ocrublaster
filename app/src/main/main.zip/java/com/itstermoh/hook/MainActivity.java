package com.itstermoh.hook;
 
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.ComponentName;
import android.annotation.NonNull;
import android.os.Message;
import android.os.Handler;
import java.util.ArrayList;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.view.View;

public class MainActivity extends Activity {
    
    private Blaster blaster;
    private Button test;
     
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        blaster = new Blaster(getApplicationContext(), usbHandler);
        blaster.initializeCommunication();
        test = findViewById(R.id.test);
        
        
        test.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                blaster.sendData(new byte[]{8,5,8,9,6,4,8,0});
            }
        });
   }
    
    private final Handler usbHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
        
        return true;
        }
    });
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (blaster != null) {
            blaster.closeCommunication();
        }
    }
}
